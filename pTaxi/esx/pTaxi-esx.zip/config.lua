-- ███╗   ██╗ ██████╗  █████╗ ██╗  ██╗██████╗  ██████╗ ███╗   ███╗██████╗  █████╗ ███████╗            ██████╗██╗  ██╗
-- ████╗  ██║██╔═══██╗██╔══██╗██║  ██║██╔══██╗██╔═══██╗████╗ ████║██╔══██╗██╔══██╗██╔════╝           ██╔════╝██║  ██║
-- ██╔██╗ ██║██║   ██║███████║███████║██████╔╝██║   ██║██╔████╔██║██████╔╝███████║███████╗           ██║     ███████║
-- ██║╚██╗██║██║   ██║██╔══██║██╔══██║██╔═══╝ ██║   ██║██║╚██╔╝██║██╔══██╗██╔══██║╚════██║           ██║     ██╔══██║
-- ██║ ╚████║╚██████╔╝██║  ██║██║  ██║██║     ╚██████╔╝██║ ╚═╝ ██║██████╔╝██║  ██║███████║    ██╗    ╚██████╗██║  ██║
-- ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝     ╚═╝╚═════╝ ╚═╝  ╚═╝╚══════╝    ╚═╝     ╚═════╝╚═╝  ╚═╝
Pombas = {}

Pombas.legacy = true -- true = legacy ||| false = esx
Pombas.delay = 5, -- command cooldown in minutes
Pombas.car = "taxi", -- Car Model
Pombas.driverModel = "s_m_m_movprem_01", -- Driver Model | https://docs.fivem.net/docs/game-references/ped-models/
Pombas.price = 0.2, -- Price per Meter
Pombas.minBalance = 50 -- Minimum Balance to call a Taxi
-- Made with ❤️ by noahpombas.ch