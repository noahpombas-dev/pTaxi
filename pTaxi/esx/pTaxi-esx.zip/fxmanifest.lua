-- Made with ❤️ by noahpombas.ch
fx_version 'cerulean'
game 'gta5'

author 'noahpombas.ch'
description 'pTaxi, made with ❤️ by noahpombas.ch'
version '1.0.0'

client_scripts {
    'client.lua',
}

server_scripts {
    '@es_extended/locale.lua',
    'server.lua'
}

shared_script 'config.lua'

dependencies {
    'es_extended'
}
-- Made with ❤️ by noahpombas.ch